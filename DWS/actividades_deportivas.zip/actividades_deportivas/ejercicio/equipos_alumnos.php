<?php
	require_once("../funciones.php");

	$conexion = conectar_pdo($host, $user, $password, $bbdd);

	if ($_SERVER['REQUEST_METHOD'] == 'POST')
    {
        // Transformamos el JSON de entrada de datos a un array asociativo
        $datos = json_decode(file_get_contents('php://input'), true);
        $insert = "INSERT INTO equipos_alumno(equipo_id, alumno_id) VALUES (:equipo_id, :alumno_id)";
        $consulta = $dbConexion->prepare($insert);
        bindAllParams($consulta, $datos);
        $consulta->execute();
        $mensajeId = $conexion -> lastInsertId();
        if($mensajeId) {
            $datos['id'] = $mensajeId;
            salidaDatos(json_encode($datos), 
            array('Content-Type: application/json', 'HTTP/1.1 200 OK'));
        }
    }


?>