<?php
	// Definición de variables
	//$host = "172.26.104.226";	// Clase
	$host = "192.168.1.50";		// Casa
	$user = "pepito01";
	$password = "pepito01";
	$bbdd = "proveedores";
?>