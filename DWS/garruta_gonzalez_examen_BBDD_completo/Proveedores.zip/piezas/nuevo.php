<?php
    // Incluye ficheros de variables y funciones
    require_once("../utiles/variables.php");
    require_once("../utiles/funciones.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alta nueva pieza</title>
    <link rel="stylesheet" type="text/css" href="../css/estilos.css">
</head>
<body>
    <h1>Alta de una nueva pieza</h1>
   <?php
  	?>
  		<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
	    	<p>
	            <!-- Campo nombre  -->
	            <input type="text" name="nombre" placeholder="Nombre" value="<?php  ?>">
	            <?php
	            ?>
	        </p>

	            <!-- Campo color  -->
	            <input type="text" name="color" placeholder="Color" value="<?php  ?>">
	            <?php
	            ?>
	        </p>

	        <p>
	            <!-- Campo precio -->
	            <input type="number" name="precio" placeholder="Precio" value="<?php  ?>">
	            <?php
	            	
	            ?>
	        </p>
	        <p>
	            <!-- Campo nombre de la categoría -->
	            <select id="categoria" name="categoria">
	            	<option value="">Seleccione Categoría</option>
	            <?php
					//Conectar a la base de datos para tomar los posibles valores de las categorías.
					//Usamos un SELECT para traer los valores del id y en nombre de la categoría.
					//Usamos el $row para darle los valores al desplegable de las categorías
  				
  				?>
  				</select>
  				
	            <?php
	            ?>
	        </p>
	        <p>
	            <!-- Botón submit -->
	            <input type="submit" value="Guadar">
	        </p>
	    </form>
  	<?php

    ?>
   <div class="contenedor">
        <div class="enlaces">
            <a href="listado.php">Volver al listado de piezas</a>
        </div>
   </div>
</body>
</html>