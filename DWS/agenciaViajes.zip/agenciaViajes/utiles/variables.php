<?php

	// Definición de variables
	
	$host ="192.168.1.138"; //casa
	//$host = "172.26.104.213"; //instituto
	$user = "pepito01";
	$password = "pepito01";
	$bbdd = "plataformadb";
?>